﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AIRecommender.CoreEngine
{
    public class RecommenderFactory
    {
        protected RecommenderFactory() { }

        public static readonly RecommenderFactory Instance = new RecommenderFactory();
        public virtual IRecommender CreateRecommender()
        {
            string className = ConfigurationManager.AppSettings["GETCORRELATION"];
            // Reflextion
            Type theType = Type.GetType(className);
            return (IRecommender)Activator.CreateInstance(theType);
        }
    }
}
