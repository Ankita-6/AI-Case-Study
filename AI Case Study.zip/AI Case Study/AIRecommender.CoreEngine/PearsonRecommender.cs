﻿using MathNet.Numerics.Statistics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.CoreEngine
{
    public class PearsonRecommender : IRecommender
    {
        public double GetCorrelation(int[] baseData1, int[] otherData1)
        {
           ArrayModifier(ref baseData1, ref otherData1);
            double correlation;
              double[] baseData = Array.ConvertAll(baseData1, item => (double)item);
              double[] otherData = Array.ConvertAll(otherData1, item => (double)item);

            

              correlation = Correlation.Pearson(baseData, otherData); 
           /*
           
            // means of x and y
            double meanX = baseData.Average();
            double meanY = otherData.Average();
            
            double numerator = 0;
            double denominatorX = 0;
            double denominatorY = 0;

            for (int i = 0; i < baseData.Length; i++)
            {
                double diffX = baseData[i] - meanX;
                double diffY = otherData[i] - meanY;

                numerator += diffX * diffY;
                denominatorX += Math.Pow(diffX, 2);
                denominatorY += Math.Pow(diffY, 2);
            }

            // Calculate the Pearson correlation coefficient
            
            if (denominatorX == 0 || denominatorY == 0)
            {
                correlation = 0; // If any denominator is 0, correlation is 0 to avoid division by zero
            }
            else
            {
                correlation = numerator / (Math.Sqrt(denominatorX) * Math.Sqrt(denominatorY));
            } */
        //   Console.WriteLine(Math.Round(correlation));
            return Math.Round(correlation,5);
        }

        public static void ArrayModifier(ref int[] baseData, ref int[] otherData)
        {
            // base array is larger or smaller than other array  - Resize
            if (baseData.Length != otherData.Length)
            {
                Array.Resize(ref otherData, baseData.Length);
            }

            // array element value is 0
            for (int i = 0; i < baseData.Length; i++)
            {
                if (baseData[i] == 0 || otherData[i] == 0)
                {
                    baseData[i] += 1;
                    otherData[i] += 1;
                }
            }
        }
    }
}
