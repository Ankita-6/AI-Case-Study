﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataAggrigator
{
    public class DataAggrigatorFactory
    {
        protected DataAggrigatorFactory() { }

        public static readonly DataAggrigatorFactory Instance = new DataAggrigatorFactory();
        public virtual IRatingsAggrigator CreateAggrigator()
        {
            string className = ConfigurationManager.AppSettings["AGGRIGATE"];
            // Reflextion
            Type theType = Type.GetType(className);
            return (IRatingsAggrigator)Activator.CreateInstance(theType);
        }
    }
}
