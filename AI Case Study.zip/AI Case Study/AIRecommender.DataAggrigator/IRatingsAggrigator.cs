﻿using AIRecommender.Entities;
using Microsoft.Win32;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataAggrigator
{
    public interface IRatingsAggrigator
    {
        ConcurrentDictionary<string, List<int>>  Aggrigate(BookDetails bookDetails, Preference preference);
       
    }
}
