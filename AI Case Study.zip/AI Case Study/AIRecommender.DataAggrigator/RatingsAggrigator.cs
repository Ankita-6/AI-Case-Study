﻿using AIRecommender.Entities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataAggrigator
{
    public class RatingsAggrigator : IRatingsAggrigator
    {
        public ConcurrentDictionary<string, List<int>> Aggrigate(BookDetails bookDetails, Preference preference)
        {
            ConcurrentDictionary<string, List<int>> ISBN_Ratings = new ConcurrentDictionary<string, List<int>>();
            string PreferenceState = preference.State;
            int PreferenceAge = preference.Age;

            string xmlFilePath = @"C:\Users\Ankita S\Desktop\AI Case Study\AIRecommender.DataAggrigator\AgeGroups.xml";
            AgeGroupClassifier classifier = new AgeGroupClassifier(xmlFilePath);

            string PreferenceAgeGroup  = classifier.ClassifyAge(PreferenceAge);

           // string PreferenceAgeGroup = AgeGroup(PreferenceAge);

            HashSet<int> PeferredUsers = new HashSet<int>();

            
            //Parallel.ForEach(bookDetails.Users, user =>
            foreach (User user in bookDetails.Users)
            {
                int age = 0;
                if (user.Age != null)
                {
                    age = (int)user.Age;
                }
                if (PreferenceState == user.State  && PreferenceAgeGroup == classifier.ClassifyAge(age))
                {
                    PeferredUsers.Add(user.UserID);
                }
            }
            
            // Parallel.ForEach(bookDetails.BookUserRatings, userRating =>
            foreach (BookUserRating userRating in bookDetails.BookUserRatings)
            {
                 if (PeferredUsers.Contains(userRating.UserID))
                 {
                    if (!ISBN_Ratings.ContainsKey(userRating.ISBN))
                    {
                        ISBN_Ratings.TryAdd(userRating.ISBN, new List<int>());
                    }
                    ISBN_Ratings[userRating.ISBN].Add(userRating.Rating);
                }
            }

            return ISBN_Ratings;
        }

        //private string AgeGroup(int age)
        //{
        //    if (age >= 1 && age <= 16)
        //        return "Teen Age";
        //    else if (age >= 17 && age <= 30)
        //        return "Young Age";
        //    else if (age >= 31 && age <= 50)
        //        return "Mid Age";
        //    else if (age >= 51 && age <= 60)
        //        return "Old Age";
        //    else if (age >= 61 && age <= 100)
        //        return "Senior Citizens";
        //    else
        //        return null;

        //}
    }
}
