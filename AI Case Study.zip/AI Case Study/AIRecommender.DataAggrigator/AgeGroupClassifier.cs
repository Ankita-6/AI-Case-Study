﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace AIRecommender.DataAggrigator
{
    public class AgeGroupClassifier
    {
        private XmlDocument ageGroupsXml;

        public AgeGroupClassifier(string xmlFilePath)
        {
            ageGroupsXml = new XmlDocument();
            ageGroupsXml.Load(xmlFilePath);
        }

        public string ClassifyAge(int age)
        {
            XmlNodeList ageGroupNodes = ageGroupsXml.SelectNodes("/AgeGroups/AgeGroup");

            foreach (XmlNode ageGroupNode in ageGroupNodes)
            {
                int minAge = int.Parse(ageGroupNode.Attributes["minAge"].Value);
                int maxAge = int.Parse(ageGroupNode.Attributes["maxAge"].Value);

                if (age >= minAge && age <= maxAge)
                    return ageGroupNode.Attributes["name"].Value;
            }

            return null; // Or throw an exception for invalid age ranges
        }
    }

}
