﻿using AIRecommender.CoreEngine;
using AIRecommender.DataAggrigator;
using AIRecommender.DataCacher;
using AIRecommender.DataLoader;
using AIRecommender.Entities;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace AIRecommender.UIClient
{
    public class AIRecommendationEngine
    {
        private IRecommender recommender;
        private IDataLoader dataLoader;
        private IRatingsAggrigator ratingsAggrigator;
        public AIRecommendationEngine(IRecommender recommender, IDataLoader dataLoader, IRatingsAggrigator ratingsAggrigator)
        {
            this.recommender = recommender;
            this.dataLoader = dataLoader;
            this.ratingsAggrigator = ratingsAggrigator;
            
        }

        public List<Book> Recommend(Preference preference, int limit)
        {
            // loading Data
             DataLoaderFactory dlFactory = DataLoaderFactory.Instance;
             DataCacherFactory dcFactory = DataCacherFactory.Instance;
           
            BooksDataService booksDataService = new BooksDataService( dcFactory.CreateDataCacher(), dlFactory.CreateDataLoader());
           
            BookDetails bookDetails = booksDataService.GetBookDetails();
           
            // Data Loader
            //   BookDetails bookDetails = dataLoader.Load();

            // Data Aggrigator
            ConcurrentDictionary<string, List<int>> ISBN_Ratings = ratingsAggrigator.Aggrigate(bookDetails, preference);

            // Get Correlation
            Dictionary<string, double> sorted_correlation_isbn = Correlation_ISBN(preference, ISBN_Ratings);


            List<string> recommended_isbn = (List<string>)sorted_correlation_isbn.Keys.Take(limit).ToList();

            List<Book> recommendedBooks = new List<Book>();

            foreach (Book b in bookDetails.Books)
            {
                if (recommended_isbn.Contains(b.ISBN))
                {
                    recommendedBooks.Add(b);
                }
            }

            return recommendedBooks;
        }

        private Dictionary<string, double> Correlation_ISBN(Preference preference, ConcurrentDictionary<string, List<int>> ISBN_Ratings)
        {

            Dictionary<string, double> correlation_isbn = new Dictionary<string, double>();
            int[] baseArray = ISBN_Ratings[preference.ISBN].ToArray();

            foreach (var kvp in ISBN_Ratings)
            {
                int[] otherArray = kvp.Value.ToArray();
                double correlation = recommender.GetCorrelation(baseArray, otherArray);
                correlation_isbn.Add(kvp.Key, correlation);

            }

            var sorted_correlation_isbn = correlation_isbn.OrderByDescending(x => x.Value)
                                         .ToDictionary(x => x.Key, x => x.Value);

            //int count = 0;
            //foreach (var item in sorted_correlation_isbn)
            //{
            //    Console.WriteLine($"ISBN : {item.Key}, Correlation : {item.Value}");
            //    count++;
            //    if (count == 10)
            //        break;
            //}

            return sorted_correlation_isbn;
        }
    }

}
