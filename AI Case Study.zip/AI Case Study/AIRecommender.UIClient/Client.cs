﻿using AIRecommender.CoreEngine;
using AIRecommender.DataAggrigator;
using AIRecommender.DataCacher;
using AIRecommender.DataLoader;
using AIRecommender.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.UIClient
{
    public class Client
    {
        static void Main(string[] args)
        {
            try
            {
                RecommenderFactory rFactory = RecommenderFactory.Instance;
                DataLoaderFactory dlFactory = DataLoaderFactory.Instance;
                DataAggrigatorFactory dAggrigator = DataAggrigatorFactory.Instance;

                AIRecommendationEngine aIRecommendationEngine = new AIRecommendationEngine(rFactory.CreateRecommender(), dlFactory.CreateDataLoader(), dAggrigator.CreateAggrigator());


                Preference preference = new Preference { ISBN = "0425182908", Age = 20, State = "california" };
                List<Book> b = aIRecommendationEngine.Recommend(preference, 5);

                Console.WriteLine($"Preference: {preference.ISBN}, State: {preference.State}, Age:{preference.Age}\n\n");
                Console.WriteLine("Recommended Books Based on Preference:\n");
                foreach (Book book in b)
                {
                    Console.WriteLine($" ISBN  : {book.ISBN} \n Title : {book.BookTitle}\n");
                }


                // to check working of cache

                Console.WriteLine("--------------------------------------------------------------------------------------");
                List<Book> b1 = aIRecommendationEngine.Recommend(preference, 5);

                Console.WriteLine($"Preference: {preference.ISBN}, State: {preference.State}, Age:{preference.Age}\n\n");
                Console.WriteLine("Recommended Books Based on Preference:\n");
                foreach (Book book in b1)
                {
                    Console.WriteLine($" ISBN  : {book.ISBN} \n Title : {book.BookTitle}\n");
                }

                Console.WriteLine("--------------------------------------------------------------------------------------");
                List<Book> b2 = aIRecommendationEngine.Recommend(preference, 5);

                Console.WriteLine($"Preference: {preference.ISBN}, State: {preference.State}, Age:{preference.Age}\n\n");
                Console.WriteLine("Recommended Books Based on Preference:\n");
                foreach (Book book in b2)
                {
                    Console.WriteLine($" ISBN  : {book.ISBN} \n Title : {book.BookTitle}\n");
                }
            }
            catch(UnableToProcessFileException ex)
            {
                Console.WriteLine(ex.InnerException.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();

        }
    }
}
