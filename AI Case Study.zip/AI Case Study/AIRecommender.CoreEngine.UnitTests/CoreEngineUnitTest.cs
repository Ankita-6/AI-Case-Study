﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace AIRecommender.CoreEngine.UnitTests
{
    
    [TestClass]
    public class CoreEngineUnitTest
    {
        
        PearsonRecommender target = null;
        [TestInitialize]
        public void Init()
        {
            target = new PearsonRecommender();
        }

        [TestCleanup]
        public void Cleanup()
        {
            target = null;
        }
        [TestMethod]
        public void GetCorrelation_EqualSizeArray_CorrelationValue()
        {
            int[] baseData = { 2, 4, 6, 8, 10 };
            int[] otherData = { 1, 3, 5, 7, 9 };
            double excepted = 1;
            double actual = target.GetCorrelation(baseData, otherData);
            Assert.AreEqual(excepted, actual);
        }

        [TestMethod]
        public void GetCorrelation_EqualSizeArrayWithValue0_CorrelationValue()
        {
            int[] baseData = { 1, 2, 0 };
            int[] otherData = { 2, 3, 5 };
            double excepted = -0.27735;
            double actual = target.GetCorrelation(baseData, otherData);
            Assert.AreEqual(excepted, actual);
        }

        [TestMethod]
        public void GetCorrelation_BaseArraySizeLarger_CorrelationValue()
        {
            int[] baseData = { 1, 2, 3, 4 };
            int[] otherData = { 1, 2, 3 };
            double excepted = -0.05096;
            double actual = target.GetCorrelation(baseData, otherData);
            Assert.AreEqual(excepted, actual);
        }

        [TestMethod]
        public void GetCorrelation_BaseArraySizeSmaller_CorrelationValue()
        {
            int[] baseData = { 1, 2, 3 };
            int[] otherData = { 1, 2, 3, 4 };
            double excepted = 1;
            double actual = target.GetCorrelation(baseData, otherData);
            Assert.AreEqual(excepted, actual);
        }



    }

   





   
}
