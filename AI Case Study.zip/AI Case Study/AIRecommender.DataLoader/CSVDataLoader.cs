﻿using AIRecommender.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;


namespace AIRecommender.DataLoader
{
    public class CSVDataLoader : IDataLoader
    {
        private readonly string Books_file = @"C:\\Users\\Ankita S\\Downloads\\BX-CSV-Dump\\BX-Books.csv";
        private readonly string BookRatings_file = @"C:\Users\Ankita S\Downloads\BX-CSV-Dump\BX-Book-Ratings.csv";
        private readonly string Users_file = @"C:\\Users\\Ankita S\\Downloads\\BX-CSV-Dump\\BX-Users.csv";
        public BookDetails Load()
        {
            BookDetails bookDetails = new BookDetails();

            List<Book> books = new List<Book>();
            List<User> users = new List<User>();
            List<BookUserRating> bookratings = new List<BookUserRating>();
          
            Parallel.Invoke(
                () => books = LoadBooks(),
                () => users = LoadUsers(),
                () => bookratings = LoadBookRatings()
              );

            bookDetails.Books = books;
            bookDetails.BookUserRatings = bookratings;
            bookDetails.Users = users;


            Book b = new Book();
            b.BookUserRatings = bookratings;
            User u = new User();
            u.BookUserRatings = bookratings;


            return bookDetails;
        }

        private List<BookUserRating> LoadBookRatings()
        {
            List<BookUserRating> bookratings = new List<BookUserRating>();

            try
            {
                using (StreamReader reader = new StreamReader(BookRatings_file))
                {
                    string header = reader.ReadLine();
                    while (!reader.EndOfStream)
                    {
                        string Str = reader.ReadLine();
                        string[] RatingInfo = Str.Split(';');
                        BookUserRating rating = new BookUserRating();
                        rating.UserID = int.Parse(RatingInfo[0].Trim('"'));
                        rating.ISBN = RatingInfo[1].Trim('"');
                        rating.Rating = int.Parse(RatingInfo[2].Trim('"'));

                        bookratings.Add(rating);

                    }
                }
            } 
            catch(Exception ex)
            {
                UnableToProcessFileException unableToProcessFileException = new UnableToProcessFileException("Could Not Load Ratings File",ex);
                throw unableToProcessFileException;
            }

           // Console.WriteLine(bookratings.Count);
            return bookratings;
        }

        private List<User> LoadUsers()
        {
            List<User> users = new List<User>();
            using (StreamReader reader = new StreamReader(Users_file))
            {
                string header = reader.ReadLine();
                while (!reader.EndOfStream)
                {

                    string Str = reader.ReadLine();
                    string[] UserInfo = Str.Split(new string[] { "\";" }, StringSplitOptions.None);

                    User User = new User();
                    User.UserID = int.Parse(UserInfo[0].Trim('"'));
                    string[] Location = UserInfo[1].Trim('"').Split(',');
                    if (Location.Length == 3)
                    {
                        User.City = Location[0].Trim(' ');
                        User.State = Location[1].Trim(' ');
                        User.Country = Location[2].Trim(' ');
                    }
                    else if (Location.Length == 2)
                    {
                        User.City = Location[0].Trim(' ');
                        User.State = Location[1].Trim(' ');
                    }
                    else if (Location[0].Length == 1)
                        User.City = Location[0].Trim(' ');

                    if (UserInfo[2] != "NULL")
                        User.Age = int.Parse(UserInfo[2].Trim('"'));
                    else
                        User.Age = null;

                    users.Add(User);
                }
            }
           // Console.WriteLine(users.Count);
            return users;
        }

        private List<Book> LoadBooks()
        {
            List<Book> books = new List<Book>();

            using (StreamReader reader = new StreamReader(Books_file))
            {
                string header = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    string Str = reader.ReadLine();
                    string[] BookInfo = Str.Split(new string[] { "\";\"" }, StringSplitOptions.None);
                    Book book = new Book();
                    book.ISBN = BookInfo[0].Trim('"');
                    book.BookTitle = BookInfo[1].Trim('"');
                    book.BookAuthor = BookInfo[2].Trim('"');
                    book.YearOfPublication = int.Parse(BookInfo[3].Trim('"'));
                    book.ImageUrlSmall = BookInfo[4].Trim('"');
                    book.ImageUrlMedium = BookInfo[5].Trim('"');
                    book.ImageUrlLarge = BookInfo[6].Trim('"');

                    books.Add(book);
                }
            }
            // Console.WriteLine(books.Count);
            return books;
        }
    }
}
