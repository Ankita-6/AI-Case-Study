﻿using AIRecommender.DataLoader;
using AIRecommender.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataCacher
{
    public class BooksDataService
    {

        private static IDataCacher dataCacher = DataCacherFactory.Instance.CreateDataCacher();
        private readonly IDataLoader dataLoader;
       
        public BooksDataService(IDataCacher dataCacher, IDataLoader dataLoader)
        {
          //  this.dataCacher = dataCacher;
            this.dataLoader = dataLoader;
        }

        public BookDetails GetBookDetails()
        {
          
           var  bookDetails = dataCacher.GetData();

            if (bookDetails == null)
            {
                Console.WriteLine("Loading from files\n");
                bookDetails = dataLoader.Load();
                dataCacher.SetData(bookDetails);
                return bookDetails;
            }

            Console.WriteLine("Loading from Cache\n"); 
            return bookDetails;
        }
    }
}
