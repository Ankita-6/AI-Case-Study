﻿using AIRecommender.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataCacher
{
    public class MemDataCacher : IDataCacher
    {
        public BookDetails BookDetails {  get; set; }

        public BookDetails GetData()
        {
            return BookDetails;
        }

        public void SetData(BookDetails bookDetails)
        {
            BookDetails = bookDetails;

        }
    }
}
