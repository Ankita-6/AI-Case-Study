﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommender.DataCacher
{
    public class DataCacherFactory
    {
        protected DataCacherFactory() { }

        public static readonly DataCacherFactory Instance = new DataCacherFactory();
        public virtual IDataCacher CreateDataCacher()
        {
            string className = ConfigurationManager.AppSettings["CACHE"];
            // Reflextion
            Type theType = Type.GetType(className);
            return (IDataCacher)Activator.CreateInstance(theType);
        }
    }
}
